clear all
clc;close all
global X0 Y0 YawA0 vx0 vy0 yawR0 Ofr0 Ofl0 Orr0 Orl0 rollA0 rollR0 Tsim 

tic
fff=linspace(0,4,9);

deltafr=pi/180*[0;2;0;-2;0;0;0;0;0];
deltafl=pi/180*[0;2;0;-2;0;0;0;0;0];


ffff=fff.';
tab=table(ffff,deltafl,deltafr);
toc

run('E:/Validation Model/myGlobals.m');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ODE Solver,tab,ffff
tic
simtime=[0:0.1:Tsim];
initialvalues=[X0 Y0 YawA0 vx0 vy0 yawR0 Ofr0 Ofl0 Orr0 Orl0 rollA0 rollR0];
[t,xa] = ode45(@(t,x)vehicle8ODEmodel(t,x,tab,ffff),simtime,initialvalues);
toc


