function [FX] =fx(alfa,slip,W,muep,cx,cy,mues)
lc=(muep*W*(1+slip))/(2*sqrt((cx*slip).^2+(cy*tan(alfa)).^2));
FXmax=muep*W;
if lc <= 1
FX=((muep*W*cx*slip)/sqrt(((cx*slip).^2)+(cy*tan(alfa)).^2))*(1-((muep*W*(1+slip))/(4*sqrt((cx*slip).^2+(cy*tan(alfa)).^2))));
    if FX > FXmax
        FX=mues*W;
    end
else
FX=(cx*slip)/(1-slip);
end