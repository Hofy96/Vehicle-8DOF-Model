function [Fy] = fy(alfa,slip,W,muep,cx,cy,mues)
lc=(muep*W*(1+slip))/(2*sqrt((cx*slip).^2+(cy*tan(alfa)).^2));
Fymax=muep*W;
if lc <= 1
Fy=((muep*W*cy*tan(alfa))/sqrt(((cx*slip).^2)+(cy*tan(alfa)).^2))*(1-((muep*W*(1+slip))/(4*sqrt((cx*slip).^2+(cy*tan(alfa)).^2))));
    if Fy > Fymax
        Fy=mues*W;
    end
else
Fy=(cy*tan(alfa))/(1-slip);

end

