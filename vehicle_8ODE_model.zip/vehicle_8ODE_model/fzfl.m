function [fz] =fzfl(ax,ay,vx,rollA)
global m g b h l ca Bf ms e 
fz=m*g*0.5*b/l-h*m*ax*0.5/l-ca*(vx^2)*0.5*h/l+ms*h*ay*b/(l*Bf)-ms*b*g*e*sin(rollA)/(l*Bf); 
end

