function G= myGlobals
global Tdfr Tdfl Tdrr Tdrl Tsim a Bf m b l Br h rawair af cd ca fr izz iz rw g cxfr cxfl cxrr cxrl Mfr Mfl Mrr Mrl Msfr Msfl Msrr Msrl cyfr cyfl cyrr cyrl e ixx ixz kphi cphi ms X0 Y0 YawA0 vx0 vy0 yawR0 Ofr0 Ofl0 Orr0 Orl0 rollA0 rollR0 
a= 1.203;
m=1280; %%vehicle mass kg
b= 1.217;%%distance from cg to rear axle m
l=a+b; %%wheel base m
Br= 1.33;%%rear track width m
Bf=1.33;%%front track width m
h= 0.5;%%hight of cg @ given mass  m
rawair= 1.2;%%air denisty  kg/m3
af= 2.1;%%frontal area  m2 
cd= 0.32;%%drag coefficient 
ca=0.5*rawair*af*cd; %%air resistance coefficient
fr=0.015; %%coefficient of rolling resistance
izz= 2500;%%1/(0.5*(a+b)^2*m);%%moment of inertia  kg*m2

Tdfr=0; %%front wheel torque N.m
Tdfl=0;
Tdrr=0; %%rear wheel torque N.m
Tdrl=0;

iz=2.1; %%Wheel moment of inertia kg.m2
rw=0.3; %%Wheel radius m
g=10;  %%gravitational acceleration m/s^2
cxfr=50000; %%logitudinal stiff. front right %%%for each wheel function%%%% N/m
cxfl=50000; %%logitudinal stiff. front left %%%for each wheel function%%%% N/m
cxrr=50000; %%logitudinal stiff. rear right %%%for each wheel function%%%% N/m
cxrl=50000; %%logitudinal stiff. rear left %%%for each wheel function%%%% N/m

Mfr=0.85; %%adhesion limit front right wheel
Mfl=0.85; %%adhesion limit front left wheel
Mrr=0.85; %%adhesion limit rear right wheel
Mrl=0.85; %%adhesion limit rear left wheel

Msfr=0.3;
Msfl=0.3;
Msrr=0.3;
Msrl=0.3;

cyfr=30000; %%cornering stiff. front rirht tire N/rad
cyfl=30000; %%cornering stiff. front left tire N/rad
cyrr=30000; %%cornering stiff. rear right tire N/rad
cyrl=30000; %%cornering stiff. rear left tire N/rad

%%%%%%%%%%%%%%%%%%%%%%%%%%% Roll parameters
e=0.2; %%Distance of the sprung mass c.g. from the roll axes m
ixx=750; %%Vehicle moment of inertia about roll axis kg.m2
ixz=0; %%Sprung mass product of inertia kg m2
kphi=45000; %%Roll axis torsional stiffness Nm/rad  (kf+kr)
cphi=2600; %%Roll axis torsional damping Nm/rad/sec (cf+cr)
ms=1160; %%sprung mass
%%%%%%%%%%%%%%%%%%%%%%%%%%% Inputs
X0=0;  %% m
Y0=0;  %% m
YawA0=0;  %% rad
vx0=10;  %% m/s
vy0=0;  %% m/s
yawR0=0;  %% rad/sec
Ofr0=vx0/rw;  %% rad/sec
Ofl0=vx0/rw;  %% rad/sec
Orr0=vx0/rw;  %% rad/sec
Orl0=vx0/rw;  %% rad/sec
rollA0=0; %% rad
rollR0=0; %% rad/sec

Tsim=4;
end

