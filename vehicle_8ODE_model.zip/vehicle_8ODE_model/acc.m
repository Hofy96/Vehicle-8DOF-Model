function [ax,ay] = acc(deltafr,deltafl,Ofr,Ofl,Orr,Orl,vx,vy,yawR,Ax,Ay,rollA)
global m cxfr cxfl cxrr cxrl Mfr Mfl Mrr Mrl Msfr Msfl Msrr Msrl cyfr cyfl cyrr cyrl ca fr
ax=(1/m)*(...,
     fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr(Ax,Ay,vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
    -fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr(Ax,Ay,vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr)...,
    +fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl(Ax,Ay,vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,
    -fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl(Ax,Ay,vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl)...,
    +fx(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr(Ax,Ay,vx,rollA),Mrr,cxrr,cyrr,Msrr)...,
    +fx(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl(Ax,Ay,vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
    -ca*vx*vx-fr*vx);

ay=(1/m)*(...,
     fy(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl(Ax,Ay,vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
    +fy(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr(Ax,Ay,vx,rollA),Mrr,cxrr,cyrr,Msrr)...,
    +fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr(Ax,Ay,vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
    +fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl(Ax,Ay,vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,
    +fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr(Ax,Ay,vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr)...,
    +fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl(Ax,Ay,vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl));

end
