function [dxdt] = vehicle8ODEmodel(t,x,tab,ffff)
global Tdfr Tdfl Tdrr Tdrl iz izz m cxfr cxfl cxrr cxrl Mfr Mfl Mrr Mrl Msfr Msfl Msrr Msrl cyfr cyfl cyrr cyrl ca fr  Br Bf a b rw ms e ixx ixz g kphi cphi 

deltafr=interp1(tab.ffff,tab.deltafr,t);
deltafl=interp1(tab.ffff,tab.deltafl,t);



X=x(1);
Y=x(2);
YawA=x(3);
vx=x(4);
vy=x(5);
yawR=x(6);
Ofr=x(7);
Ofl=x(8);
Orr=x(9);
Orl=x(10);
rollA=x(11);
rollR=x(12);

dxdt = zeros(12,1);

dxdt(1)=vx*cos(YawA)-vy*sin(YawA);
dxdt(2)=-vx*sin(YawA)-vy*cos(YawA);

dxdt(3)=yawR;

dxdt(4)=vy*yawR+(1/m)*(...,
     fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
    -fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr)...,
    +fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,
    -fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl)...,
    +fx(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrr,cxrr,cyrr,Msrr)...,
    +fx(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
    -ca*vx*vx-fr*vx);

dxdt(5)=-vx*yawR+(1/m)*((-ms*e*dxdt(12))...,
    +fy(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
    +fy(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrr,cxrr,cyrr,Msrr)...,
    +fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
    +fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,
    +fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr)...,
    +fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl));

dxdt(6)= (1/izz)*((ixx*dxdt(12))...,
      +a*(fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
         +fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,
         +fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl)...,
         +fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr))...,
      -b*(fy(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
         +fy(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrr,cxrr,cyrr,Msrr))...,
 +(Br/2)*(fx(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrl,cxrl,cyrl,Msrl)...,
         -fx(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrr,cxrr,cyrr,Msrr))...,
 +(Bf/2)*(fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*cos(deltafl)...,      
         -fy(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)*sin(deltafl)...,
         -fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*cos(deltafr)...,
         +fy(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)*sin(deltafr)));

dxdt(7)=(1/iz)*(-rw*fx(alfafr(deltafr,vy,vx,yawR),slipd(Ofr,ufr(deltafr,vy,vx,yawR)),fzfr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfr,cxfr,cyfr,Msfr)+Tdfr);

dxdt(8)=(1/iz)*(-rw*fx(alfafl(deltafl,vy,vx,yawR),slipd(Ofl,ufl(deltafl,vy,vx,yawR)),fzfl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mfl,cxfl,cyfl,Msfl)+Tdfl);

dxdt(9)=(1/iz)*(-rw*fx(alfarr(vy,vx,yawR),slipd(Orr,urr(vx,yawR)),fzrr((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrr,cxrr,cyrr,Msrr)+Tdrr);

dxdt(10)=(1/iz)*(-rw*fx(alfarl(vy,vx,yawR),slipd(Orl,url(vx,yawR)),fzrl((dxdt(4)-vy*yawR),(dxdt(5)+vx*yawR),vx,rollA),Mrl,cxrl,cyrl,Msrl)+Tdrl);   

dxdt(11)=rollR;

dxdt(12)=(1/ixx)*((-ms*e*(dxdt(5)+vx*yawR))+ms*g*e*sin(rollA)+ixz*dxdt(6)-kphi*rollA-cphi*rollR);
           
end
