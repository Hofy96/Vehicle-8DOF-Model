function [si] = slipd(omega,wpspeed)

global rw
si=(rw*omega-wpspeed)/max(abs(rw*omega),abs(wpspeed));
end

