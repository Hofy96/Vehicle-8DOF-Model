function [u] = urr(vx,yawrate)
global Br
u=vx-0.5*Br*yawrate;
end

