function [u] = ufr(delta,vy,vx,yawrate)
global Bf a 
u=((vx-0.5*Bf*yawrate)*cos(delta)+(vy+a*yawrate)*sin(delta));
end

