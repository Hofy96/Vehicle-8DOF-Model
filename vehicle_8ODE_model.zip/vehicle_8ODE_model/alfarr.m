function [alfa] = alfarr(vy,vx,yawrate)

global b Br
alfa=(-atan((vy-b*yawrate)/(vx-0.5*Br*yawrate)));
end

