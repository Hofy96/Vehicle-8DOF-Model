function [fz] =fzrr(ax,ay,vx,rollA)
global m g a h l ca Br ms e 
fz=m*g*0.5*a/l+h*m*ax*0.5/l+ca*(vx^2)*0.5*h/l-ms*h*ay*a/(l*Br)+ms*g*a*e*sin(rollA)/(l*Br); 
end

