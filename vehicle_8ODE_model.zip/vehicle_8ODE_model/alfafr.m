function [alfa] = alfafr(delta,vy,vx,yawrate)
global a Bf
alfa=(delta-(atan((vy+a*yawrate)/(vx-0.5*Bf*yawrate))));
end

